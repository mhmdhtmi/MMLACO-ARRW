# Data and preprocessing

The manuscript evaluates MMLACO-ARRW on real-world multi-label datasets. This repository does **not** redistribute those third-party datasets.

## Required local format

The current reproducibility notebook expects a headerless CSV:

- first `d` columns: numerical/categorical feature representation used by the experiment;
- next `q` columns: binary multi-label targets.

For Scene, the manuscript reports:

- 2,407 instances;
- 294 features;
- 6 labels;
- 40 selected features.

Before running the manuscript experiments, verify that the local CSV contains exactly the same instances, feature ordering, label ordering, and preprocessing used to generate the paper's results.

## Dataset provenance

The manuscript identifies the MULAN multi-label dataset collection as the source of the benchmark datasets. The public MULAN dataset page is:

https://mulan.sourceforge.net/datasets-mlc.html

The corresponding MULAN library paper is:

Tsoumakas, G., Spyromitros-Xioufis, E., Vilcek, J., & Vlahavas, I. (2011). MULAN: A Java library for multi-label learning. Journal of Machine Learning Research, 12, 2411–2414.

Do not upload third-party datasets to this repository unless redistribution is permitted.

## Reproducibility note

If the final manuscript uses a preprocessing/conversion step from ARFF/XML or another original representation to CSV, that conversion script should be added to `scripts/` before the repository is cited in the paper. The current notebook documents the CSV interface but cannot infer an unseen preprocessing pipeline from the supplied notebook alone.
