# Reproducibility protocol

## 1. Environment

Use Python 3.10 and install the pinned dependencies from `requirements.txt`.

## 2. Dataset

Use the same benchmark files and preprocessing as the manuscript. Do not substitute a different copy or a differently encoded dataset.

## 3. Feature selection

For each dataset:

1. compute feature–feature and feature–label mutual information;
2. construct the inverse-MI transition heuristic;
3. initialize pheromone values to 0.1;
4. run 50 ACO iterations;
5. use `d` ants when `d < 100`, otherwise 100 ants;
6. use `q0 = 0.6`, `β = 1`, and `ρ = 0.1`;
7. visit the desired feature budget per ant;
8. evaluate candidate subsets with the relevance–redundancy criterion;
9. reinforce pheromone according to candidate scores;
10. rank features by final pheromone and select the required number.

## 4. ARRW

Use:

- α_max = 0.9
- α_min = 0.1
- γ_t = 1 − α_t

The first iteration therefore uses `(α, γ) = (0.9, 0.1)` and the final iteration uses `(0.1, 0.9)`.

## 5. Evaluation

The manuscript uses ML-kNN with `k = 10` and a 70/30 train-test split. The main experiments report ten independent runs. Record the seed for every run.

## 6. Ablation

For MMLACO-Fixed vs MMLACO-ARRW:

- use the same dataset;
- use the same feature budget;
- use the same ACO settings;
- use the same train/test protocol;
- use paired seeds where possible;
- change only the relevance–redundancy weighting mode.

## 7. What to archive

For each run, archive:

- random seed;
- dataset name and dimensions;
- selected feature indices;
- final pheromone values;
- runtime;
- metric values;
- environment/package versions.

This makes the computational record auditable without publishing third-party datasets.

## 8. Recommended execution

Use `scripts/run_repeated_experiments.py` for the proposed method. It performs the
feature-selection procedure independently for each seed and evaluates the selected
subset using ML-kNN. It writes both run-level values and a mean ± standard deviation
summary.

The repository currently contains the supplied proposed-method implementation and
its ARRW ablation. It does not include implementations of every literature baseline,
because those methods may have separate licenses/authors and were not supplied with
the current code package.
