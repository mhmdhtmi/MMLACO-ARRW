# Publishing this repository on GitHub

## Recommended route: GitHub Desktop

1. Install GitHub Desktop and sign in to your GitHub account.
2. Create a local repository from this folder or add this existing folder.
3. Review the files before publishing. In particular, confirm that no private manuscript, email, password, API key, or restricted dataset is present.
4. Publish the repository with **Public** visibility.
5. Copy the resulting repository URL into `CITATION.cff` and the manuscript response letter.

## Browser route

1. On GitHub, choose **New repository**.
2. Use the name `MMLACO-ARRW`.
3. Choose **Public**.
4. Do not upload third-party datasets unless redistribution is permitted.
5. Upload the repository files and commit them.

## Final checks before telling the editor/reviewer that the code is public

- The repository opens without authentication in a private/incognito browser.
- `README.md` explains installation and execution.
- `requirements.txt` is present.
- `notebooks/MMLACO_ARRW_Reproducibility.ipynb` opens.
- `src/mmlaco_arrw.py` contains the implementation.
- `configs/scene.yaml` records the manuscript parameters.
- `docs/REPRODUCIBILITY.md` explains the protocol.
- No confidential information is present.
- The URL in the response letter is the real repository URL, not a placeholder.
