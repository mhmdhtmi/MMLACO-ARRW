Generated run-level outputs may be stored here locally. Do not commit large/generated files unless they are needed for reproducibility and contain no restricted data.
