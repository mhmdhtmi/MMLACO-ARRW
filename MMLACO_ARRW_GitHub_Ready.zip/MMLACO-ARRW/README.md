# MMLACO-ARRW: Mutual Information-Based Multi-Label Feature Selection

Reference implementation and reproducibility materials for the manuscript:

**Mutual Information-Based Multi-Label Feature Selection via Ant Colony Optimization**

The repository contains the implementation of **MMLACO-ARRW**, which extends the fixed-weight MMLACO formulation with **Adaptive Relevance–Redundancy Weighting (ARRW)**.

## What is implemented?

MMLACO-ARRW uses:

- mutual information for feature–label relevance and feature–feature redundancy;
- Ant Colony Optimization (ACO) for candidate-subset exploration;
- pheromone reinforcement based on candidate-subset scores;
- ARRW, which changes the relevance/redundancy balance over ACO iterations.

The manuscript-aligned ARRW schedule starts from `(α, γ) = (0.9, 0.1)` and ends at `(0.1, 0.9)`.

## Repository structure

```text
.
├── configs/
│   └── scene.yaml
├── data/
│   └── README.md
├── docs/
│   ├── DATA.md
│   └── REPRODUCIBILITY.md
├── notebooks/
│   └── MMLACO_ARRW_Reproducibility.ipynb
├── results/
│   └── README.md
├── scripts/
│   └── run_mmlaco.py
├── src/
│   └── mmlaco_arrw.py
├── tests/
│   └── test_arrw.py
├── CITATION.cff
├── LICENSE
├── README.md
└── requirements.txt
```

## Experimental protocol

The reproducibility configuration follows the values reported in the manuscript:

| Setting | Value |
|---|---:|
| ACO iterations | 50 |
| Pheromone evaporation ρ | 0.1 |
| Initial pheromone | 0.1 |
| q₀ | 0.6 |
| β | 1 |
| α_max | 0.9 |
| α_min | 0.1 |
| γ_min | 0.1 |
| γ_max | 0.9 |
| Selected features | 40 (8 for Flags) |
| Number of ants | d if d < 100; otherwise 100 |
| ML-kNN k | 10 |
| Train/test split | 70/30 |
| Main repeated experiments | 10 independent runs |

**Important:** The repository does not redistribute third-party datasets. The numerical results in the paper must be regenerated from the same dataset files and preprocessing used for the manuscript. See `docs/DATA.md`.

## Installation

Python 3.10 is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run the reproducibility notebook

Place a prepared dataset at `data/scene.csv`, then open:

```text
notebooks/MMLACO_ARRW_Reproducibility.ipynb
```

The CSV format is:

```text
feature_1,...,feature_d,label_1,...,label_q
```

with no header, matching the loader in the notebook.

## Run ten independent runs with ML-kNN

```bash
python scripts/run_repeated_experiments.py \
  --data data/scene.csv \
  --features 294 \
  --labels 6 \
  --selected 40 \
  --runs 10 \
  --start-seed 0 \
  --mode arrw \
  --mlknn-k 10 \
  --output results/scene_arrw_runs.csv
```

The script produces run-level metrics and a separate mean/standard-deviation summary. This is the recommended route for regenerating the proposed-method results rather than relying on a single demonstration run.

## Run from the command line

For Scene:

```bash
python scripts/run_mmlaco.py ^
  --data data/scene.csv ^
  --features 294 ^
  --labels 6 ^
  --selected 40 ^
  --mode arrw ^
  --seed 0 ^
  --output results/scene_arrw_seed0.json
```

On macOS/Linux, replace `^` with `\`.

The script records the dataset dimensions, seed, selected features, runtime, and ARRW endpoint values.

## Reproducibility safeguards

The implementation explicitly records:

1. dataset dimensions;
2. ACO parameters;
3. ARRW parameters;
4. random seed;
5. selected-feature budget;
6. ML-kNN configuration;
7. train/test split configuration;
8. output feature rankings and ARRW schedule.

The fixed and ARRW variants can be run with the same seed for a paired ablation comparison.

## Dataset policy

Third-party datasets are not committed to this repository unless their redistribution terms explicitly permit it. This avoids publishing external data without authorization. The exact dataset provenance and expected local file format are documented in `docs/DATA.md`.

## Relation to the manuscript

The repository is intended to support faithful reproduction and independent verification of the algorithmic procedure. It should not be interpreted as a replacement for the manuscript's full experimental tables. Before submission, regenerate the manuscript's reported tables/figures from the final dataset files and retain the run-level outputs.

## Citation

Please cite the associated article when using this implementation. See `CITATION.cff`.

## License

The source code is released under the MIT License. Third-party datasets and third-party dependencies remain subject to their own licenses and terms.
